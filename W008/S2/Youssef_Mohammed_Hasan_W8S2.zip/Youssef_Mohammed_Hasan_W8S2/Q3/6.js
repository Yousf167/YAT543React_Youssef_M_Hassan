//performs all basic arithmetic results on two numbers and returns the result
function basicOpps(x, y) {
      return {
            sum: x + y,
            diff: x - y,
            prod: x * y,
            div: x / y
      }
}


console.log(basicOpps(1,2));
